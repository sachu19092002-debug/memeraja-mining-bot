# MemeRaja Mining: Admin + PPC Wallet starter

## Render setup
Create a **Web Service** (not a Static Site) connected to this GitHub repository.

- Build Command: `pip install -r requirements.txt`
- Start Command: `python app.py`
- Runtime: Python 3

Set these Environment Variables in Render:
- `BOT_TOKEN` = token from BotFather
- `ADMIN_ID` = your numeric Telegram user ID
- `ADMIN_PASSWORD` = strong unique password, at least 12 characters
- `FLASK_SECRET_KEY` = random secret string, at least 32 characters
- `DB_PATH` = `/var/data/memeraja.db` (when a persistent disk is mounted at `/var/data`)
- `MINING_REWARD` = `50`
- `REFERRAL_REWARD` = `100`
- `MIN_WITHDRAWAL` = `500`

Attach a Render Persistent Disk mounted at `/var/data` before relying on real balances. SQLite data on an ephemeral filesystem may be lost on redeploy/restart.

Open `https://YOUR-SERVICE.onrender.com/admin/login` to access the admin panel.

## Important limitations before public launch
- This starter runs Flask in a background thread and Telegram polling on the main thread. Use the provided `python app.py` start command; do not run multiple copies of this service.
- This is a starter implementation, not a security audit. Add CSRF protection, rate limiting, HTTPS-only session cookie settings, audit logging, and stronger task-verification before a public launch.
- Task submission is user-attested; admin must manually review before PPC is credited.
- Withdrawal requests reserve PPC immediately. Rejected requests refund PPC. Approval only changes status; send crypto separately, then mark the request paid and save the transaction hash.
- The current withdrawal form accepts an address but does not yet collect a network. Confirm and implement the exact crypto coin/network before accepting real requests; never ask users for seed phrases or private keys.
- PPC is an in-app point balance unless you implement a real token and payment flow. Do not advertise a guaranteed cash value.
- Do not use the Static Site service for this Python app. The existing static site can remain as a separate front-end, but this service is the bot + admin backend.
